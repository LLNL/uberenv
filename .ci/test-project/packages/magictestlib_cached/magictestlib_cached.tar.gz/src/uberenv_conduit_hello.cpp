#include <iostream>
int
main(int argc, char *argv[])
{
    std::cout << "Hello from uberenv-conduit." << std::endl;
    return 0;
}
